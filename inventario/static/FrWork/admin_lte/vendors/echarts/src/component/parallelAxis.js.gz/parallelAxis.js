define(function(require) {

    require('../coord/parallel/parallelCreator');
    require('./axis/parallelAxisAction');
    require('./axis/ParallelAxisView');

});