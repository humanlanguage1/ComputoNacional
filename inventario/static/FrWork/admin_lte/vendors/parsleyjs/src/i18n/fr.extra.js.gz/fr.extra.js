// Validation errors messages for Parsley
import Parsley from '../parsley';

Parsley.addMessages('fr', {
  dateiso: "Cette valeur n'est pas une date valide (YYYY-MM-DD).",
  notequalto: "Cette valeur doit être différente."
});
